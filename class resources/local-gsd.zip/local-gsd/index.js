// ===========================
// Local To-Do App (Front End)
// Saves tasks using localStorage
// ===========================

// Get HTML elements (DOM elements)
const taskInput = document.getElementById("taskInput");
const addBtn = document.getElementById("addBtn");
const taskList = document.getElementById("taskList");

// This is the key (String) we use to store tasks in localStorage
const STORAGE_KEY = "tasks";

// This Array will hold all tasks in memory while the page is open
// Each task is an Object: { id: Number, text: String, done: Boolean }
let tasks = [];

// ---------------------------
// READ: load tasks on page start
// ---------------------------
loadTasks();
renderTasks();

// ---------------------------
// CREATE: add a new task
// ---------------------------
addBtn.addEventListener("click", () => {
	// Get the text from the input (String)
	const text = taskInput.value.trim();

	// Basic validation: ignore empty input
	if (text === "") return;

	// Create a task object
	const task = {
		id: Date.now(), // Number (unique enough for class demos)
		text: text, // String
		done: false, // Boolean
	};

	// Add task to the Array (CREATE)
	tasks.push(task);

	// Save and re-draw
	saveTasks();
	renderTasks();

	// Clear input for the next task
	taskInput.value = "";
	taskInput.focus();
});

// ---------------------------
// UPDATE + DELETE using event delegation
// (One listener for the whole list)
// ---------------------------
taskList.addEventListener("click", (event) => {
	const target = event.target;

	// Each button stores the task id in data-id (String -> convert to Number)
	const id = Number(target.dataset.id);

	// If you clicked a "Done" button: UPDATE the done Boolean
	if (target.className === "doneBtn") {
		tasks = tasks.map((task) => {
			if (task.id === id) {
				return { ...task, done: !task.done };
			}
			return task;
		});

		saveTasks();
		renderTasks();
	}

	// If you clicked a "Delete" button: DELETE the task
	if (target.className === "deleteBtn") {
		tasks = tasks.filter((task) => task.id !== id);

		saveTasks();
		renderTasks();
	}

	// If you clicked an "Edit" button: UPDATE the text String
	if (target.className === "editBtn") {
		const newText = prompt("Edit task:", getTaskText(id));

		// If user cancels, prompt returns null
		if (newText === null) return;

		// Trim and ignore empty edits
		const cleanText = newText.trim();
		if (cleanText === "") return;

		tasks = tasks.map((task) => {
			if (task.id === id) {
				return { ...task, text: cleanText };
			}
			return task;
		});

		saveTasks();
		renderTasks();
	}
});

// Helper: get task text by id (used for Edit prompt)
function getTaskText(id) {
	const task = tasks.find((t) => t.id === id);
	return task ? task.text : "";
}

// ---------------------------
// READ: show tasks on the page
// ---------------------------
function renderTasks() {
	// Clear the list (so we don’t double-up tasks)
	taskList.innerHTML = "";

	// Build the list again from the tasks Array
	for (const task of tasks) {
		// Create <li>
		const li = document.createElement("li");

		// Show a tick if done (simple visual)
		const status = task.done ? "☑🔲" : " ☐ ";

		// Text content
		const textSpan = document.createElement("span");
		textSpan.textContent = status + task.text;

		// Done button (UPDATE)
		const doneBtn = document.createElement("button");
		doneBtn.textContent = "Done";
		doneBtn.className = "doneBtn";
		doneBtn.dataset.id = task.id;

		// Edit button (UPDATE)
		const editBtn = document.createElement("button");
		editBtn.textContent = "Edit";
		editBtn.className = "editBtn";
		editBtn.dataset.id = task.id;

		// Delete button (DELETE)
		const deleteBtn = document.createElement("button");
		deleteBtn.textContent = "Delete";
		deleteBtn.className = "deleteBtn";
		deleteBtn.dataset.id = task.id;

		// Put it all into the <li>
		li.appendChild(textSpan);
		li.appendChild(doneBtn);
		li.appendChild(editBtn);
		li.appendChild(deleteBtn);

		// Add <li> to the <ul>
		taskList.appendChild(li);
	}
}

// ---------------------------
// SAVE: store tasks in localStorage
// ---------------------------
function saveTasks() {
	// localStorage only stores Strings, so we convert Array -> JSON String
	localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
}

// ---------------------------
// LOAD: get tasks from localStorage
// ---------------------------
function loadTasks() {
	const saved = localStorage.getItem(STORAGE_KEY);

	// If nothing saved yet, keep tasks as empty Array
	if (saved === null) {
		tasks = [];
		return;
	}

	// Convert JSON String -> Array of Objects
	tasks = JSON.parse(saved);
}
